import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javaforce.*;

/** Entry point for jphonelite application. */

public class PhoneApp extends JFrame implements WindowListener, WindowController {
  public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(new Runnable() {
      public void run() {
        new PhoneApp().setVisible(true);
      }
    });
  }

  private PhonePanel panel;

  private PhoneApp() {
    panel = new PhonePanel(this, false);
    addWindowListener(this);
    setResizable(false);
    setContentPane(panel);
    pack();
    setTitle("jPhoneLite/" + PhonePanel.version);
    setPosition();
  }
//interface WindowListener
  public void windowOpened(WindowEvent e) { }
  public void windowClosing(WindowEvent e) { panel.unRegisterAll(); System.exit(0); }
  public void windowClosed(WindowEvent e) { }
  public void windowIconified(WindowEvent e) {
    if (Settings.current.hideWhenMinimized) {
      setVisible(false);
    }
  }
  public void windowDeiconified(WindowEvent e) { }
  public void windowActivated(WindowEvent e) {
    panel.active = true;
  }
  public void windowDeactivated(WindowEvent e) {
    panel.active = false;
  }
//interface WindowController
  public void setPanelSize() {
    pack();
  }
  public void setPanelVisible() {
    setVisible(true);
    setExtendedState(NORMAL);
  }
  public void setPanelAlwaysOnTop(boolean state) {
    setAlwaysOnTop(state);
  }
  public void startFlash() {}
  public void stopFlash() {}
  public void setPosition() {
    Dimension d = getPreferredSize();
    Rectangle s = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    setLocation(s.width/2 - d.width/2, s.height/2 - d.height/2);
  }
}

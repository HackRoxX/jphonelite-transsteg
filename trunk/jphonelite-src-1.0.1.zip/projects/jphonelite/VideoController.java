/**
 * Created : Nov 27, 2012
 *
 * @author pquiring
 */

public interface VideoController {
  public void toggleVideoPanel();  
}

jPhoneLite/1.0.1

Java VoIP SoftPhone (SIP)
http://jphonelite.sourceforge.net
License : LGPL

Supports : g711u/a, g729a, RFC 2833, 6 lines w/ conference, hold, transfer and video (JPEG).
Conference Mode : Set for each line (up to all 6 lines)

jPhoneLite is part of the JavaForce SDK (http://javaforce.sourceforge.net)
By : Peter Quiring (pquiring at gmail dot com)

Need a FREE Java-based PBX?  Try jPBXlite.
Available at http://jpbxlite.sourceforge.net

Need a FREE Java-based AutoDialer? Try jfBroadcast.
Available at http://jfbroadcast.sourceforge.net

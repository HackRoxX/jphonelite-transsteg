<html>
<head>
  <title>jPhoneLite</title>
</head>
<body leftmargin=0 rightmargin=0 topmargin=0 bottommargin=0 vlink=ffffff link=ffffff alink=ffffff width=100% height=100% bgcolor=777777>
<center>
<applet code="PhoneApplet" archive="jphonelite-signed.jar,javaforce-signed.jar" width=560 height=350></applet>
</center>
</body>
</html>

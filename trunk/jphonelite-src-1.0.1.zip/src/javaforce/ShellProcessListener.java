package javaforce;

public interface ShellProcessListener {

  public void shellProcessOutput(String str);
}
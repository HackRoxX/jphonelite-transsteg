/* G729aI18N - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package javaforce.codec.g729a;

import java.util.ResourceBundle;

class G729aI18N {

  static String getString(String string) {
    return ResourceBundle.getBundle("codecLib.g729a.G729aExceptionStrings").getString(string);
  }
}
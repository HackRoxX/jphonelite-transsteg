/* g729a_tilt_filter - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */
package javaforce.codec.g729a;

final class g729a_tilt_filter {

  float x1;

  void print(String string) {
    System.err.println(string + "=" + g729a_utils.HF(x1));
  }
}
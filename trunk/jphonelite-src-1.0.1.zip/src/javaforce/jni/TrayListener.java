package javaforce.jni;

/**
 * Created : Aug 8, 2012
 *
 * @author pquiring
 */
public interface TrayListener {

  public void trayEvent(int msg, int count);
}
